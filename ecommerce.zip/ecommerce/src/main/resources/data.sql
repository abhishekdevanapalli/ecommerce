insert into Product (id, desc, mrp, selling_price,user, quantity) values
(
   10001,
   'Apple iPhone 11 Pro (Space Grey, 512 GB)',
   'Rs.1,50,000',
   'Rs.1,40,300',
   'E-commerce','20'
);
insert into Product (id, desc, mrp, selling_price,user, quantity) values
(
   10002,
   'Samsung Galaxy Note 10 (Aura Black, 256 GB)  (8 GB RAM)',
   'Rs.80,000',
   'Rs.73,600',
   'E-commerce','5'
);
insert into Product (id, desc, mrp, selling_price,user, quantity) values
(
   10003,
   'Motorola Razr (Black, 128 GB)  (6 GB RAM)',
   'Rs.1,40,000',
   'Rs.1,24,999',
   'E-commerce',
   '10'
);


insert into order_table (email, id, quantity) values ('user@gmail.com', 1002, 6);